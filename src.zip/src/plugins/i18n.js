import Vue from "vue";
import VueI18n from "vue-i18n";
import Vuetify from "vuetify";
import english from "@/store/translation/en.json";
import {
  getJSONFromFile
} from "@/utils/fileUtilities.js";
Vue.use(VueI18n);
Vue.use(Vuetify);
// eslint-disable-next-line
let customConfiguration = require("@/configuration_properties.json");
customConfiguration = getJSONFromFile(customConfiguration);
const englishLanguage = Object.assign(english.commonComponents.login,
    english.commonComponents.drawer,
    english.commonComponents.pageNotFound,
    english.commonComponents.idleDialog,
    english.functionalComponents.manageProfile,
    english.functionalComponents.organization,
    english.functionalComponents.organizationJiraProject,
    english.functionalComponents.home,
    english.functionalComponents.configurationsProperties,
    english.functionalComponents.projectTask,
    english.functionalComponents.resourceFilter,
    english.functionalComponents.demandAndSupplyAnalysis,
    english.schemaParser.common,
    english.schemaParser.translation,
    english.configurationsProperties,
    english.schemaParser,
    english.serverProperties),
  messages = {
    "en": englishLanguage
  };

export const i18n = new VueI18n({
  "fallbackLocale": customConfiguration.languageSettings.selectedLanguage,
  "locale": customConfiguration.languageSettings.selectedLanguage,
  messages
});
