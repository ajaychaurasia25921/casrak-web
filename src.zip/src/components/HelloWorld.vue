<template>
  <v-container wrap>
    <v-layout wrap>
      <v-flex xs12 md6 lg5 class="app-text">
        <h1>
          <b>
            <i>
            <br/>
            BE A PART OF FUTURE SOLUTION
            </i>
            </b>
          </h1>
          </v-flex>
      <v-flex xs12 lg6>
        <v-card :rounded="true" max-width="400" class="ml-auto">
          <v-system-bar></v-system-bar>
          <v-carousel
            :continuous="true"
            :cycle="cycle"
            :interval="interval"
            :show-arrows="false"
            hide-delimiter-background
            delimiter-icon="mdi-minus"
            height="200"
          >
            <v-carousel-item v-for="(item,i) in items" :key="i" :src="require(`@/assets/image/${item.src}`)"></v-carousel-item>
          </v-carousel>
          <v-system-bar></v-system-bar>
        </v-card>
      </v-flex>
      <v-flex xs12 lg6>
      <v-card>
            <v-system-bar></v-system-bar>
        </v-card>
        </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      items: [
        {
          src: "API.png",
        },
        {
          src: "mobApp.png",
        },
        {
          src: "webApp.png",
        },
        {
          src: "micro.png",
        }
      ],
      cycle: true,
      interval: 6000,
    };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
