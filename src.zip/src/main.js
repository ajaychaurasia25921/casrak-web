import "./plugins/vuetify";
import App from "./App.vue";
import Vue from "vue";
import Vuetify from "vuetify";
import vuetify from "./plugins/vuetify";
Vue.use(Vuetify);
new Vue({
    "render": h => {
        return h(App);
    },
    vuetify
}).$mount("#app");