<template>
  <v-flex xs11 sm11 md11 lg11 xl11>
    <font :color="primaryColor">{{$t(schema.labels)}}</font>
    <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
    <v-autocomplete
      v-model="value"
      autocomplete
      clearable
      clear-icon
      @change="evaluate(schema.method)"
      :items="schema.values"
      :required="schema.required"
      :disabled="schema.disabled"
      :readonly="schema.readonly"
      :minlength="schema.minlength"
      :maxlength="schema.maxlength"
      :color="primaryColor"
      :rules="rules"
    ></v-autocomplete>
    <!-- TODO: Handle autocomplete in standard material design approach -->
    <!-- :label="schema.label" -->
  </v-flex>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  props: ["model"],
  mixins: [abstractField],
  mounted() {
    if (this.schema.required) {
      this.rules.push(v => !!v || "Required");
    }
  },
  data() {
    return {
      storedValues: [],
      local: "",
      localStoredOrgResource: "",
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  methods: {
    evaluate(methodName) {
      this.$root.$emit("dynamicMethodCall", methodName);
    }
  },
  watch: {
    value: function() {
      this.$root.$emit("methodCall", "");
    }
  }
};
</script>