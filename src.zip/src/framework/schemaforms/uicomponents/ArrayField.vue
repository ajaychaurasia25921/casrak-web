<template>
  <v-flex v-if="schema">
    <v-layout
      row
      :id="fieldId"
      v-for="(item, index) in value"
      :class="schema.itemContainerClasses"
      :style="schema.itemContainerStyle"
      :key="index"
    >
      <component
        class="flex pa-0"
        v-if="schema.items"
        :is="getFieldType(schema.items)"
        :rules="rules"
        :model="item"
        :schema="generateSchema(value, schema.items, index)"
        :formOptions="formOptions"
      />
      <v-icon
        :color="secondaryColor"
        :class="schema.removeElementButtonClasses"
        @click="removeElement(index)"
        v-if="schema.showRemoveIcon"
      >{{schema.removeElementButtonIcon}}</v-icon>
      <v-btn
        :color="primaryColor"
        v-if="schema.showNewIcon"
        small
        class="white--text"
        @click="newElement"
      >{{newElementButtonLabel}}</v-btn>
    </v-layout>
  </v-flex>
</template>

<script>
import VueFormGenerator from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
import cloneDeep from "lodash.clonedeep";
import Vue from "vue";
export default {
  mixins: [VueFormGenerator.abstractField],
  mounted() {
    if (this.schema.required) {
      this.rules.push(v => !!v || "Required");
    }
  },
  data() {
    return {
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  computed: {
    fieldId() {
      return this.getFieldID(this.schema);
    },
    newElementButtonLabel() {
      if (typeof this.schema.newElementButtonLabel !== "undefined") {
        return this.schema.newElementButtonLabel;
      }
      return "+ New";
    },
    removeElementButtonLabel() {
      if (typeof this.schema.removeElementButtonLabel != "undefined") {
        return this.schema.removeElementButtonLabel;
      }
      return "x";
    }
  },
  methods: {
    generateSchema(rootValue, schema, index) {
      if (!schema) {
        schema = {};
      }
      if (typeof this.schema.inputName !== "undefined") {
        schema.inputName = this.schema.inputName + "[" + index + "]";
      }
      schema.id = this.fieldId + index;
      return {
        ...schema,
        set(model, value) {
          Vue.set(rootValue, index, value);
        },
        get(model) {
          model;
          return rootValue[index];
        }
      };
    },
    generateInputName(index) {
      if (typeof this.schema.inputName === "undefined") {
        return null;
      }
      return this.schema.inputName + "[" + index + "]";
    },
    newElement() {
      let value = this.value;
      let itemsDefaultValue = undefined;
      if (!value || !value.push) value = [];
      if (this.schema.items && this.schema.items.default) {
        itemsDefaultValue = cloneDeep(this.schema.items.default);
      }
      value.push(itemsDefaultValue);
      this.value = [...value];
    },
    removeElement(index) {
      this.value.splice(index, 1);
    },
    getFieldType(fieldSchema) {
      return "field-" + fieldSchema.type;
    }
  }
};
</script>
