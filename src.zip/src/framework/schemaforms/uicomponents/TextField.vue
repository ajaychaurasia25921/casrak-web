<template>
  <div>
    <v-layout row wrap>
      <v-flex>
        <font :color="primaryColor">{{$t(schema.labels)}}</font>
        <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
        <v-text-field
          :label="schema.label"
          :readonly="schema.readonly"
          :disabled="schema.disabled"
          :required="schema.required"
          :hint="schema.hint"
          :minlength="schema.minlength"
          :maxlength="schema.maxlength"
          :placeholder="$t(schema.placeholder)"
          :default="schema.default"
          v-model="value"
          :color="primaryColor"
          :rules="rules"
        ></v-text-field>
      </v-flex>
    </v-layout>
  </div>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  mixins: [abstractField],
  mounted() {
    if (this.schema.required) {
      this.rules = [v => !!v || "Required"];
    }
  },
  data() {
    return {
      models: "",
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  watch: {
    model: function() {
      this.schema.model = this.models;
    }
  }
};
</script>
