<template>
  <v-layout row wrap>
    <v-flex xs11 sm11 md11 lg11 xl11>
      <font :color="primaryColor">{{$t(schema.labels)}}</font>
      <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
      <v-text-field
        :readonly="schema.readonly"
        :disabled="schema.disabled"
        :required="schema.required"
        :hint="schema.hint"
        :placeholder="$t(schema.placeholder)"
        :default="schema.default"
        v-model="value"
        :id="schema.model"
        :rules="rules"
        :minlength="schema.min"
        :maxlength="schema.max"
        :color="primaryColor"
        v-bind:pattern="schema.pattern"
      ></v-text-field>
    </v-flex>
  </v-layout>
</template>
<script>
import {
  abstractField
} from "vue-form-generator";
import {
  error,
  info,
  primaryColor,
  secondaryColor,
  success,
  warning
} from "@/themes/themeUtil.js";
let errors;
export default {
  "mixins": [abstractField],
  "computed": {
    // TODO-Disable fields based on condition
    isDisabled() {
      return false;
    }
  },
  mounted() {
    this.rules = [];

    /*
     *Iif (this.schema.max) this.rules.push(v => {return v.length <= this.schema.max ||
     *       this.$t("maxErrorMesage") + this.schema.max + this.$t("charcter")});
     */
    /*
     *Iif (this.schema.min) this.rules.push(v => {
     *   return !v ||
     *       v.length >= this.schema.min ||
     *       this.$t("minErrorMessage") + this.schema.min + this.$t("charcter");
     * });
     */
    if (this.schema.required) this.rules.push(v => {
      return Boolean(v) || this.$t("required");
    });
    if (this.schema.pattern) this.rules.push(v => {
      const pattern = new RegExp(this.schema.pattern);
      return (
        pattern.test(v) ||
          `${this.$t("patternErrorMessage")
          }Pattern should be ${
            this.schema.displayPattern}`
      );
    });

    return this.rules;
  },
  data() {
    return {
      "rule_message": "",
      "models": "",
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      "rules": [],
      "errors": [],
      "errorMessage": ""
    };
  }
};
</script>
