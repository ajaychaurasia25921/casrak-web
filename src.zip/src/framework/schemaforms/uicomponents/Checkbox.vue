<template>
  <v-container>
    <font :color="primaryColor">{{$t(schema.labels)}}</font>
    <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
    <v-checkbox
      v-for="(item,index) in schemaValues"
      :key="index"
      v-model="schema.model"
      :label="item"
      :value="item"
      :required="schema.required"
      :readonly="schema.readonly"
      :disabled="schema.disabled"
      :color="primaryColor"
      :rules="rules"
    ></v-checkbox>
  </v-container>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  mixins: [abstractField],
  beforeMount() {
    this.schemaValues = this.schema.values;
  },
  mounted() {
    if (this.schema.required) {
      this.rules.push(v => !!v || "Required");
    }
  },
  data() {
    return {
      selected: "",
      schemaValues: "",
      label: this.schema.label,
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      rules: [],
      warning
    };
  },
  watch: {
    selected: function() {
      this.schema.model = this.selected;
    }
  }
};
</script>