<template>
  <div>
    <font :color="primaryColor">{{$t(schema.labels)}}</font>
    <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
    <v-switch v-model="value" :color="primaryColor" :rules="rules"></v-switch>
  </div>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  mixins: [abstractField],
  mounted() {
    this.rules = [];
    if (this.schema.required) {
      this.rules = [v => !!v || "Required"];
    }
  },
  data() {
    return {
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  }
};
</script>