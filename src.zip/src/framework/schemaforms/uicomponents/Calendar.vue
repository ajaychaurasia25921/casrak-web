<template>
  <v-layout>
    <v-flex xs11 sm11 md11 lg11 xl11>
      <font :color="primaryColor">{{$t(schema.labels)}}</font>
      <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
      <v-menu
        ref="menu"
        v-model="menu"
        :close-on-content-click="false"
        :nudge-right="40"
        transition="scale-transition"
        offset-y
        full-width
        min-width="290px"
      >
        <template v-slot:activator="{ on }">
          <v-text-field
            v-model="value"
            prepend-icon="event"
            readonly
            v-on="on"
            :error-messages="message()"
          ></v-text-field>
        </template>
        <v-date-picker
          ref="picker"
          v-model="value"
          min="1950-01-01"
          @change="dateValidation(schema.method,value)"
        ></v-date-picker>
      </v-menu>
    </v-flex>
  </v-layout>
</template>
<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
let result = false;
export default {
  mixins: [abstractField],
  mounted() {
    if (this.schema.required) {
      this.rules.push(v => !!v || "Required");
    }
  },
  data() {
    return {
      date: null,
      messages: "",
      menu: false,
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  methods: {
    message() {
      if (this.schema.method) {
        this.$root.$on("dateValidationResult", args => {
          result = args;
        });
        if (result) return "Should be more than start date";
      }
    },
    dateValidation(methodName, val) {
      if (this.schema.method) {
        this.$root.$emit("dateValidater", { name: methodName, value: val });
      }
    }
  }
};
</script>
<style>
.v-btn:not(.v-btn--depressed):not(.v-btn--flat) {
  box-shadow: none;
  min-width: 0%;
  /* box-shadow: 0 3px 1px -2px rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 1px 5px 0 rgba(0,0,0,.12); */
}
.v-btn {
  min-width: 0%;
}
</style>
