<template>
  <div>
    <font :color="primaryColor">{{$t(schema.labels)}}</font>
    <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
    <v-radio-group
      v-model="value"
      :required="schema.required"
      :readonly="schema.readonly"
      :disabled="schema.disabled"
      :hint="schema.hint"
      row
      :color="primaryColor"
      :rules="rules"
    >
      <v-radio
        :color="primaryColor"
        v-for="value in schema.values"
        :key="value.id"
        :label="value.id"
        :value="value.value"
      ></v-radio>
    </v-radio-group>
  </div>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  mixins: [abstractField],
  beforeMount() {
    this.radioGroup = this.schema.model;
  },
  mounted() {
    if (this.schema.required) {
      this.rules = [v => !!v || "Required"];
    }
  },
  data() {
    return {
      radioGroup: "",
      states: [],
      values: [],
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  watch: {
    radioGroup: function() {
      this.schema.model = this.radioGroup;
    }
  }
};
</script>