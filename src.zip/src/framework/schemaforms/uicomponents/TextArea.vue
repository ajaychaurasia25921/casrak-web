<template>
  <v-layout>
    <v-flex xs11 sm10 md10 lg10 xl11>
      <font :color="primaryColor">{{$t(schema.labels)}}</font>
      <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
      <v-textarea
        v-model="value"
        name="input-7-1"
        :value="schema.value"
        :hint="schema.hint"
        outline
        :readonly="schema.readonly"
        :required="schema.required"
        :disabled="schema.disabled"
        :placeholder="$t(schema.placeholder)"
        :default="schema.default"
        :minlength="schema.minlength"
        :maxlength="schema.maxlength"
        :color="primaryColor"
        :rules="rules"
      ></v-textarea>
    </v-flex>
  </v-layout>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  mixins: [abstractField],
  mounted() {
    if (this.schema.required) {
      this.rules = [v => !!v || "Required"];
    }
  },
  data() {
    return {
      models: "",
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  watch: {
    model: function() {
      this.schema.model = this.models;
    }
  }
};
</script>
