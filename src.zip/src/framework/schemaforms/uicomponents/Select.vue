<template>
  <v-layout>
    <v-flex xs12 sm12 md4 lg12 xl12>
      <font :color="primaryColor">{{$t(schema.labels)}}</font>
      <font :color="secondaryColor">&nbsp;{{schema.required?'*':''}}</font>
      <v-select
        v-model="value"
        :items="schema.values"
        :label="schema.label"
        :readonly="schema.readonly"
        :required="schema.required"
        :disabled="schema.disabled"
        :placeholder="$t(schema.placeholder)"
        :default="schema.default"
        :color="primaryColor"
        :rules="rules"
      ></v-select>
    </v-flex>
  </v-layout>
</template>

<script>
import { abstractField } from "vue-form-generator";
import {
  primaryColor,
  secondaryColor,
  info,
  error,
  success,
  warning
} from "@/themes/themeUtil.js";
export default {
  mixins: [abstractField],
  mounted() {
    if (this.schema.required) {
      this.rules = [v => !!v || "Required"];
    }
  },
  data() {
    return {
      modelSelect: "",
      primaryColor,
      secondaryColor,
      info,
      error,
      success,
      warning,
      rules: []
    };
  },
  watch: {
    modelSelect: function() {
      this.schema.model = this.modelSelect;
    }
  }
};
</script>
