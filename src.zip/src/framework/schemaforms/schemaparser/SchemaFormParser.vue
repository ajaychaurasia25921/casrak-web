<template>
  <v-app id="htm">
    <v-content>
      <v-flex class="container grid-list-xl fluid">
        <v-layout row wrap>
          <v-dialog v-model="dataExistsAlert" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('dataExistsMessage_dialog')}}!!!</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="dataExistsAlert=false;"
                >{{$t('dataExistsMessage_gotItButton_text')}}!!</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-dialog v-model="deleteConfirmEditAuto" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('deleteMessage_dialog')}}</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  name="deleteConfirmEditAutos"
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditAutos();"
                >{{$t('yes_text')}}</v-btn>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditAuto=false;"
                >{{$t('no_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!--Delete select Element-->
          <v-dialog v-model="deleteConfirmEditSelect" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('deleteMessage_dialog')}}?</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  name="deleteConfirmEditSelects"
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditSelects();"
                >{{$t('yes_text')}}</v-btn>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditSelect=false;"
                >{{$t('no_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!--ADD AUTO COMPLETE ELEMENT DIALOG-->
          <v-dialog v-model="optionsAutoComplete" max-width="75%">
            <v-flex v-if="type == 'AutocompleteField' ">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('option_label')}}</v-toolbar>
                <v-form ref="form" v-model="AutoValid" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs5 md2 sm2 lg2 xl2>
                        <v-text-field
                          v-model="key"
                          :label="$t('header_ID')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs5 md2 sm2 lg2 xl2>
                        <v-text-field
                          v-model="value"
                          :label="$t('header_value')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!AutoValid"
                        >
                          <v-icon name="autoCompleteAdd" @click="autoCompleteAdd(key,value);">add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
                <v-data-table :items="autoCompleteTableArray" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_ID')}}</th>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label') }}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item.text }}</td>
                    <td class="text-xs-left">{{ props.item.value }}</td>
                    <td class="text-xs-left">
                      <v-icon small class="mr-2" @click="editAutoItem(props.item);">edit</v-icon>
                      <v-icon small @click="deleteAuto(props.item);">delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>
              <v-card v-if="editAutoDialog">
                <v-toolbar
                  dark
                  class="title font-weight-light toolbar-height"
                  :color="secondaryColor"
                >
                  <p class="text-alignment">{{$t('autoItemEdit_dialog')}}</p>
                </v-toolbar>
                <v-card-text class="card-height">
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs6 sm8 md6>
                        <v-text-field
                          v-model="editAutoID"
                          :color="primaryColor"
                          :label="$t('header_ID')"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs6 sm6 md6>
                        <v-text-field
                          v-model="editAutoValue"
                          :color="primaryColor"
                          :label="$t('header_value')"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn
                    :color="primaryColor"
                    dark
                    small
                    @click="editAutoItemSave(editAutoID,editAutoValue);"
                  >{{$t('saveButton_text')}}</v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-dialog>

          <!--ADD CHECKLIST ELEMENT DIALOG-->
          <v-dialog v-model="optionsChecklist" max-width="75%">
            <v-flex v-if="type == 'Checklist' ">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('option_label')}}</v-toolbar>
                <v-form ref="checkListform" v-model="ChecklistValid" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="checklistValues"
                          :label="$t('enter_value_Field_label')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 md1 sm1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!ChecklistValid"
                        >
                          <v-icon class="white--text" @click="checklistAdd(checklistValues);">add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
                <v-data-table :items="checklistTableArray" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item}}</td>
                    <td class="text-xs-left">
                      <v-icon small class="mr-2" @click="editChecklistItem(props.item);">edit</v-icon>
                      <v-icon
                        small
                        @click="deleteChecklistItem(props.item);deleteConfirmEditChecklist = true;"
                      >delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>
            </v-flex>
            <v-card v-if="editChecklistDialog">
              <v-toolbar
                dark
                class="title font-weight-light toolbar-height"
                :color="secondaryColor"
              >
                <p class="text-alignment">{{$t('checklistItemEdit_dialog')}}</p>
              </v-toolbar>
              <v-card-text>
                <v-container grid-list-md>
                  <v-layout wrap>
                    <v-flex xs9 md3 sm3 lg3 xl3>
                      <v-text-field
                        v-model="editCheckList"
                        :color="primaryColor"
                        :label="$t('enter_value_Field_label')"
                      ></v-text-field>
                    </v-flex>
                  </v-layout>
                </v-container>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="editChecklistSave(editCheckList);"
                >{{$t('saveButton_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!--ADD SELECT FIELD ELEMENT DIALOG-->
          <v-dialog v-model="optionsSelect" max-width="75%">
            <v-flex v-if="type == 'SelectField' ">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('option_label')}}</v-toolbar>
                <v-form v-model="SelectValid" ref="SelectValids" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="selectValue"
                          :required="true"
                          :label="$t('enter_value_Field_label')"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 md1 sm1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!SelectValid"
                        >
                          <v-icon class="white--text" @click="selectValueAdd(selectValue);">add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
                <v-data-table :items="selectTableValues" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item}}</td>
                    <td class="text-xs-left">
                      <v-icon small class="mr-2" @click="editSelectItems(props.item);">edit</v-icon>
                      <v-icon small @click="deleteSelectItem(props.item);">delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>

              <v-card v-if="selectDialog">
                <v-toolbar
                  dark
                  class="title font-weight-light toolbar-height"
                  :color="secondaryColor"
                >
                  <p class="text-alignment">{{$t('selectItemEdit__dialog')}}</p>
                </v-toolbar>

                <v-card-text class="card-height">
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="editSelectItem"
                          :label="$t('enter_value_Field_label')"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn
                    :color="primaryColor"
                    dark
                    small
                    @click="editSelectSave(editSelectItem);"
                  >{{$t('saveButton_text')}}</v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-dialog>

          <!--ADD RADIO ELEMENT DIALOG-->
          <v-dialog v-model="optionsRadio" max-width="75%">
            <v-flex v-if="type == 'RadioField' ">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('option_label')}}</v-toolbar>
                <v-form ref="radioForm" v-model="RadioValid" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="radiosValues"
                          :label="$t('enter_value_Field_label')"
                          :required="true"
                          :rules="rule"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 md1 sm1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!RadioValid"
                        >
                          <v-icon class="white--text" @click="radiosAdd(radiosValues);">add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
                <v-data-table :items="radioTableArray" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item}}</td>
                    <td class="text-xs-left">
                      <v-icon small class="mr-2" @click="editRadioItems(props.item);">edit</v-icon>
                      <v-icon small @click="deleteRadioItem(props.item);">delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>
              <v-card v-if="editRadioDialog">
                <v-toolbar
                  dark
                  class="title font-weight-light toolbar-height"
                  :color="secondaryColor"
                >
                  <p class="text-alignment">{{$t('radioItemEdit_dialog')}}</p>
                </v-toolbar>
                <v-card-text class="card-height">
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          :color="primaryColor"
                          v-model="editRadioItem"
                          :label="$t('enter_value_Field_label')"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn
                    :color="primaryColor"
                    dark
                    small
                    @click="editRadioSave(editRadioItem);"
                  >{{$t('saveButton_text')}}</v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-dialog>

          <!--EDIT AUTOCOMPLETE FIELD ELEMENT DIALOG-->
          <v-dialog v-model="optionsEditAutoComplete" max-width="75%">
            <v-card v-if="editType == 'AutocompleteField' ">
              <v-toolbar
                dark
                class="title font-weight-light"
                :color="secondaryColor"
              >{{$t('option_label')}}</v-toolbar>
              <v-flex v-if="editType == 'AutocompleteField' ">
                <v-form ref="form" v-model="AutoValid" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs5 md2 sm2 lg2 xl2>
                        <v-text-field
                          v-model="key"
                          :label="$t('header_ID')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs5 md2 sm2 lg2 xl2>
                        <v-text-field
                          v-model="value"
                          :label="$t('header_value')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 sm1 md1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!AutoValid"
                        >
                          <v-icon
                            :color="primaryColor"
                            class="white--text"
                            @click="autoCompleteAdd(key,value);"
                          >add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
              </v-flex>
              <v-data-table :items="autoCompleteTableArray" class="elevation-1" hide-actions>
                <template slot="headers">
                  <tr>
                    <th class="text-xs-left">{{ $t('header_ID')}}</th>
                    <th class="text-xs-left">{{ $t('header_value')}}</th>
                    <th class="text-xs-left">{{ $t('table_actions_label') }}</th>
                  </tr>
                </template>
                <template slot="items" slot-scope="props">
                  <td class="text-xs-left">{{ props.item.text}}</td>
                  <td class="text-xs-left">{{ props.item.value }}</td>
                  <td class="text-xs-left">
                    <v-icon small class="mr-2" @click="editAutoItem(props.item);">edit</v-icon>
                    <v-icon slot="activator" small @click="deleteAuto(props.item);">delete</v-icon>
                  </td>
                </template>
              </v-data-table>
            </v-card>

            <v-card v-if="editAutoDialog">
              <v-toolbar
                dark
                class="title font-weight-light toolbar-height"
                :color="secondaryColor"
              >
                <p class="text-alignment">{{$t('autoItemEdit_dialog')}}</p>
              </v-toolbar>

              <v-card-text class="card-height">
                <v-container grid-list-md>
                  <v-layout wrap>
                    <v-flex xs6 sm8 md6>
                      <v-text-field
                        :color="primaryColor"
                        v-model="editAutoID"
                        :label="$t('header_ID')"
                      ></v-text-field>
                    </v-flex>
                    <v-flex xs6 sm8 md6>
                      <v-text-field
                        :color="primaryColor"
                        v-model="editAutoValue"
                        :label="$t('header_value')"
                      ></v-text-field>
                    </v-flex>
                  </v-layout>
                </v-container>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="editAutoItemSave(editAutoID,editAutoValue);"
                >{{$t('saveButton_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!--EDIT CHECK LIST ELEMENT DIALOG-->
          <v-dialog v-model="optionsEditChecklist" max-width="75%">
            <v-flex v-if="editType == 'Checklist' ">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('checklistItemEdit_dialog')}}</v-toolbar>
                <v-form ref="checkListform" v-model="ChecklistValid" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="checklistValues"
                          :label="$t('enter_value_Field_label')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 md1 sm1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!ChecklistValid"
                        >
                          <v-icon
                            :color="primaryColor"
                            class="white--text"
                            @click="checklistAdd(checklistValues);"
                          >add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
                <v-data-table :items="checklistTableArray" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item}}</td>
                    <td class="text-xs-left">
                      <v-icon
                        name="editChecklistItem"
                        small
                        class="mr-2"
                        @click="editChecklistItem(props.item);"
                      >edit</v-icon>
                      <v-icon
                        name="deleteChecklistItem"
                        small
                        @click="deleteChecklistItem(props.item);"
                      >delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>
              <v-card v-if="editChecklistDialog">
                <v-toolbar
                  dark
                  class="title font-weight-light toolbar-height"
                  :color="secondaryColor"
                >
                  <p class="text-alignment">{{$t('checklistItemEdit_dialog')}}</p>
                </v-toolbar>
                <v-card-text class="card-height">
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          :color="primaryColor"
                          v-model="editCheckList"
                          :label="$t('enter_value_Field_label')"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn
                    :color="primaryColor"
                    dark
                    small
                    @click="editChecklistSave(editCheckList);"
                  >{{$t('saveButton_text')}}</v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-dialog>

          <!--EDIT RADIO FIELD DIALOG-->
          <v-dialog v-model="optionsEditRadio" max-width="75%">
            <v-flex v-if="editType == 'RadioField'">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('option_label')}}</v-toolbar>
                <v-form ref="radioForm" v-model="RadioValid" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="radiosValues"
                          :label="$t('enter_value_Field_label')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 md1 sm1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!RadioValid"
                        >
                          <v-icon
                            :color="primaryColor"
                            class="white--text"
                            @click="radiosAdd(radiosValues);"
                          >add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>
                <v-data-table :items="radioTableArray" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item}}</td>
                    <td class="text-xs-left">
                      <v-icon small class="mr-2" @click="editRadioItems(props.item);">edit</v-icon>
                      <v-icon small @click="deleteRadioItem(props.item);">delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>
              <v-card v-if="editRadioDialog">
                <v-toolbar
                  dark
                  class="title font-weight-light toolbar-height"
                  :color="secondaryColor"
                >
                  <p class="text-alignment">{{$t('radioItemEdit_dialog')}}</p>
                </v-toolbar>
                <v-card-text class="card-height">
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          :color="primaryColor"
                          v-model="editRadioItem"
                          :label="$t('enter_value_Field_label')"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn
                    :color="primaryColor"
                    dark
                    small
                    @click="editRadioSave(editRadioItem);"
                  >{{$t('saveButton_text')}}</v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-dialog>

          <!--EDIT SELECT FIELD ELEMENT DIALOG-->
          <v-dialog v-model="optionsEditSelect" max-width="75%">
            <v-flex v-if="editType == 'SelectField' ">
              <v-card>
                <v-toolbar
                  dark
                  class="title font-weight-light"
                  :color="secondaryColor"
                >{{$t('option_label')}}</v-toolbar>
                <v-form v-model="SelectValid" ref="SelectValids" lazy-validation>
                  <v-container>
                    <v-layout>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="selectValue"
                          :label="$t('enter_value_Field_label')"
                          :required="true"
                          :rules="rule"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                      <v-flex xs1 md1 sm1 lg1 xl1>
                        <v-btn
                          :color="primaryColor"
                          class="white--text"
                          fab
                          small
                          :disabled="!SelectValid"
                        >
                          <v-icon
                            :color="primaryColor"
                            class="white--text"
                            @click="selectValueAdd(selectValue);"
                          >add</v-icon>
                        </v-btn>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-form>

                <v-data-table :items="selectTableValues" class="elevation-1" hide-actions>
                  <template slot="headers">
                    <tr>
                      <th class="text-xs-left">{{ $t('header_value')}}</th>
                      <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                    </tr>
                  </template>
                  <template slot="items" slot-scope="props">
                    <td class="text-xs-left">{{ props.item}}</td>
                    <td class="text-xs-left">
                      <v-icon small class="mr-2" @click="editSelectItems(props.item);">edit</v-icon>
                      <v-icon small @click="deleteSelectItem(props.item);">delete</v-icon>
                    </td>
                  </template>
                </v-data-table>
              </v-card>

              <v-card v-if="selectDialog">
                <v-toolbar
                  dark
                  class="title font-weight-light toolbar-height"
                  :color="secondaryColor"
                >
                  <p class="text-alignment">{{$t('selectItemEdit_dialog')}}</p>
                </v-toolbar>
                <v-card-text class="card-height">
                  <v-container grid-list-md>
                    <v-layout wrap>
                      <v-flex xs9 md3 sm3 lg3 xl3>
                        <v-text-field
                          v-model="editSelectItem"
                          :label="$t('enter_value_Field_label')"
                          :color="primaryColor"
                        ></v-text-field>
                      </v-flex>
                    </v-layout>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn
                    :color="primaryColor"
                    dark
                    small
                    @click="editSelectSave(editSelectItem);"
                  >{{$t('saveButton_text')}}</v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-dialog>

          <!--DELETE CHECKLIST ELEMENT DIALOG-->
          <v-dialog v-model="deleteConfirmEditChecklist" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('deleteMessage_dialog')}}?</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  name="deleteConfirmEditChecklists"
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditChecklists();"
                >{{$t('yes_text')}}</v-btn>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditChecklist=false;"
                >{{$t('no_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!--DELETE AUTOCOMPLETE ELEMENT DIALOG-->
          <v-dialog v-model="deleteConfirmEditRadio" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('deleteMessage_dialog')}}?</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  name="deleteConfirmEditRadios"
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditRadios();"
                >{{$t('yes_text')}}</v-btn>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmEditRadio=false;"
                >{{$t('no_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!--DELETE RADIO ELEMENT DIALOG-->
          <v-dialog v-model="deleteConfirmRadio" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('deleteMessage_dialog')}}?</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteRadioItem();"
                >{{$t('yes_text')}}</v-btn>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteConfirmRadio=false;"
                >{{$t('no_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <!--DELETE MAIN TABLE DATA DIALOG-->
          <v-dialog v-model="deleteMainTable" max-width="300">
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="secondaryColor">
                <p class="text-alignment">{{$t('deleteMessage_dialog')}}?</p>
              </v-toolbar>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  name="deleteMainTables"
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteMainTables();"
                >{{$t('yes_text')}}</v-btn>
                <v-btn
                  :color="primaryColor"
                  dark
                  small
                  @click="deleteMainTable=false;"
                >{{$t('no_text')}}</v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <v-flex xs12 sm12 md12 lg12 xl12>
            <v-card>
              <v-toolbar dark class="title font-weight-light height" :color="primaryColor">
                <p>{{ $t('screenMaintainenceComponent_title') }}</p>
              </v-toolbar>
              <v-card-text class="pa-4">
                <v-layout row>
                  <v-flex xs12 sm5 md6 lg6 xl6>
                    <v-select
                      id="selectSec"
                      v-model="selectschema"
                      :items="allschema"
                      :label="$t('schemaSelect_card_selectSchemaField_label')"
                      required
                      :color="primaryColor"
                      @change="selectSec(selectschema);"
                    ></v-select>
                  </v-flex>
                  <v-flex xs12 sm6 md6 lg6 xl6>
                    <v-select
                      v-model="selectSection"
                      :items="languageSchemaContent"
                      :label="$t('schemaSelect_card_selectSectionField_label')"
                      @change="selectSections(selectSection)"
                      required
                      :color="primaryColor"
                    ></v-select>
                  </v-flex>
                </v-layout>
              </v-card-text>
            </v-card>
            <br>
            <v-tabs
              v-model="active"
              :color="primaryColor"
              dark
              slider-color="red"
              v-if="displayTable"
            >
              <v-tab
                ripple
                class="title font-weight-light text-none"
              >{{$t('attributes_card_title')}}</v-tab>
              <v-tab
                ripple
                class="title font-weight-light text-none"
              >{{$t('formPreview_card_title')}}</v-tab>
              <v-spacer/>
              <v-btn fab flat small icon @click="onLoad()" :color="primaryColor">
                <v-icon medium class="white--text">refresh</v-icon>
              </v-btn>
              <!-------------------------------------ATTRIBUTES TAB-------------------------------------------->
              <v-tab-item>
                <template>
                  <v-data-table :items="tableContent" class="elevation-1">
                    <template slot="headers">
                      <tr>
                        <th class="text-xs-left">{{ $t('key_field_label')}}</th>
                        <th class="text-xs-left">{{ $t('label_field_label')}}</th>
                        <th class="text-xs-left">{{ $t('table_type_field_label')}}</th>
                        <th class="text-xs-left">{{ $t('table_required_label')}}</th>
                        <th class="text-xs-left">{{ $t('table_actions_label')}}</th>
                      </tr>
                    </template>
                    <template slot="items" slot-scope="props">
                      <td class="text-xs-left">{{ props.item.key }}</td>
                      <td class="text-xs-left">{{ props.item.label }}</td>
                      <td class="text-xs-left">{{ props.item.type }}</td>
                      <td class="text-xs-left">{{ props.item.required }}</td>
                      <td class="handle text-xs-left">
                        <v-icon
                          name="editFiel"
                          small
                          class="mr-2"
                          @click="editFiel(props.item);"
                        >edit</v-icon>
                        <v-icon
                          name="deleteItem"
                          small
                          slot="activator"
                          @click="deleteItem(props.item);"
                        >delete</v-icon>
                        <v-icon name="addNewFiel" small @click="addNewFiel();">add</v-icon>
                        <v-icon small class="sortHandle" style="cursor: move;">swap_vert</v-icon>
                      </td>
                    </template>
                  </v-data-table>
                  <br>

                  <!--Add Screen Attributes-->
                  <v-card v-if="addNewField">
                    <v-toolbar dark class="title font-weight-light height" :color="primaryColor">
                      <p class="text-alignment">{{$t('addScreenAttributes_card_title')}}</p>
                    </v-toolbar>
                    <v-form ref="addForm" v-model="addFieldValid" lazy-validation>
                      <v-flex xs12 md12 sm12 lg12 xl12>
                        <v-card flat>
                          <v-layout row wrap>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <v-text-field
                                name="fieldName"
                                v-model="fieldName"
                                :label="$t('key_field_label')"
                                :rules="ruleAdd"
                                :required="true"
                                :color="primaryColor"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <v-text-field
                                name="title"
                                v-model="title"
                                :label="$t('label_field_label')"
                                :color="primaryColor"
                                :required="true"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <v-select
                                v-model="type"
                                :items="types"
                                :label="$t('table_type_field_label')"
                                :required="true"
                                :color="primaryColor"
                              >
                                <template
                                  v-slot:append-outer
                                  v-if="type == 'AutocompleteField'||type == 'Checklist'||type == 'SelectField'||type == 'RadioField' "
                                >
                                  <v-icon
                                    name="addOptions"
                                    :key="icon-true"
                                    :color="primaryColor"
                                    @click="addOptions();"
                                  >edit</v-icon>
                                </template>
                              </v-select>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type=='Calendar'">
                              <v-text-field
                                v-model="placeholder"
                                :label="$t('placeholder_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type!='Calendar'">
                              <v-text-field
                                name="placeholder"
                                :color="primaryColor"
                                v-model="placeholder"
                                :label="$t('placeholder_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type=='Calendar'">
                              <v-text-field
                                v-model="defaultText"
                                :label="$t('default_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type!='Calendar'">
                              <v-text-field
                                name="defaultText"
                                :color="primaryColor"
                                v-model="defaultText"
                                :label="$t('default_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type=='Calendar'">
                              <v-text-field v-model="hint" :label="$t('hint_field_label')" disabled></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type!='Calendar'">
                              <v-text-field
                                name="hint"
                                :color="primaryColor"
                                v-model="hint"
                                :label="$t('hint_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex
                              xs6
                              sm4
                              md4
                              lg4
                              xl4
                              v-if="type=='AutocompleteField' || type=='RadioField'
                            || type=='SelectField'|| type=='RadioField'|| type=='Checklist'|| type=='Label' || type=='CheckboxField'
                            || type=='Calendar'"
                            >
                              <v-text-field
                                name="minLength"
                                v-model="minLength"
                                :label="$t('minLength_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-else>
                              <v-text-field
                                name="minLength"
                                :color="primaryColor"
                                v-model="minLength"
                                :label="$t('minLength_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type=='Calendar'">
                              <v-text-field
                                v-model="maxLength"
                                :label="$t('maxLength_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="type!='Calendar'">
                              <v-text-field
                                name="maxLength"
                                :color="primaryColor"
                                v-model="maxLength"
                                :label="$t('maxLength_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('table_required_label')}}?</span>
                              <v-radio-group id="required" v-model="required" row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('disabled_label')}}?</span>
                              <v-radio-group id="disable" v-model="disable" xs1 row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('highlight_label')}}?</span>
                              <v-radio-group id="featured" v-model="featured" xs1 row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('readonly_label')}}?</span>
                              <v-radio-group id="readonly" v-model="readonly" xs1 row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                          </v-layout>
                          <p class="text-xs-right">
                            <v-btn
                              name="addSaveSchema"
                              :color="primaryColor"
                              dark
                              @click="addSaveSchema();"
                            >{{$t('saveButton_text')}}</v-btn>
                          </p>
                        </v-card>
                      </v-flex>
                    </v-form>
                  </v-card>

                  <!--Edit Screen Attributes-->
                  <v-card v-if="editField">
                    <v-toolbar dark class="title font-weight-light height" :color="primaryColor">
                      <p class="text-alignment">{{$t('editScreenAttributes_card_title')}}</p>
                    </v-toolbar>
                    <v-form ref="editForm" v-model="editFieldValid" lazy-validation>
                      <v-flex xs12 md12 sm12 lg12 xl12>
                        <v-card flat>
                          <v-layout row wrap>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <v-text-field
                                v-model="editFieldName"
                                :label="$t('key_field_label')"
                                required
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <v-text-field
                                :color="primaryColor"
                                v-model="editTitle"
                                :label="$t('label_field_label')"
                                required
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <v-select
                                v-model="editType"
                                :items="types"
                                :label="$t('table_type_field_label')"
                                required
                                :color="primaryColor"
                              >
                                <template
                                  v-slot:append-outer
                                  v-if="editType == 'AutocompleteField'||editType == 'Checklist'||editType == 'SelectField'||editType == 'RadioField' "
                                >
                                  <v-icon
                                    name="editOptions"
                                    :key="icon-true"
                                    :color="primaryColor"
                                    @click="editOptions();"
                                  >edit</v-icon>
                                </template>
                              </v-select>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType=='Calendar'">
                              <v-text-field
                                v-model="editPlaceHolder"
                                :label="$t('placeholder_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType!='Calendar'">
                              <v-text-field
                                :color="primaryColor"
                                v-model="editPlaceHolder"
                                :label="$t('placeholder_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType=='Calendar'">
                              <v-text-field
                                v-model="editDefaultText"
                                :label="$t('default_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType!='Calendar'">
                              <v-text-field
                                :color="primaryColor"
                                v-model="editDefaultText"
                                :label="$t('default_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType=='Calendar'">
                              <v-text-field
                                v-model="editHint"
                                :label="$t('hint_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType!='Calendar'">
                              <v-text-field
                                :color="primaryColor"
                                v-model="editHint"
                                :label="$t('hint_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex
                              xs6
                              sm4
                              md4
                              lg4
                              xl4
                              v-if="editType=='AutocompleteField' || editType=='RadioField' || editType=='SelectField' 
                            || editType=='Checklist'|| editType=='Label'|| editType=='CheckboxField' || editType=='Calendar'"
                            >
                              <v-text-field
                                v-model="editMinLength"
                                :label="$t('minLength_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-else>
                              <v-text-field
                                :color="primaryColor"
                                v-model="editMinLength"
                                :label="$t('minLength_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType=='Calendar'">
                              <v-text-field
                                v-model="editMaxLength"
                                :label="$t('maxLength_field_label')"
                                disabled
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4 v-if="editType!='Calendar'">
                              <v-text-field
                                :color="primaryColor"
                                v-model="editMaxLength"
                                :label="$t('maxLength_field_label')"
                              ></v-text-field>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('table_required_label')}}?</span>
                              <v-radio-group v-model="required" row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('disabled_label')}}?</span>
                              <v-radio-group v-model="disable" xs1 row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('highlight_label')}}?</span>
                              <v-radio-group v-model="featured" xs1 row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                            <v-flex xs6 sm4 md4 lg4 xl4>
                              <span class="body-1">{{$t('readonly_label')}}?</span>
                              <v-radio-group v-model="readonly" xs1 row>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('yes_text')"
                                  :value="true"
                                ></v-radio>
                                <v-radio
                                  :color="primaryColor"
                                  :label="$t('no_text')"
                                  :value="false"
                                ></v-radio>
                              </v-radio-group>
                            </v-flex>
                          </v-layout>
                          <p class="text-xs-right">
                            <v-btn
                              name="editaddSaveSchema"
                              :color="primaryColor"
                              dark
                              @click="editaddSaveSchema();"
                            >{{$t('saveButton_text')}}</v-btn>
                          </p>
                        </v-card>
                      </v-flex>
                    </v-form>
                  </v-card>
                </template>
              </v-tab-item>
              <!-------------------------------------FORM PREVIEW TAB-------------------------------------------->
              <v-tab-item>
                <v-layout>
                  <v-flex xs12 sm12 md12 lg12 xl12>
                    <v-card class="pa-1">
                      <v-toolbar dark class="title font-weight-light height" :color="primaryColor">
                        <p class="text-alignment">{{$t('languageDetails_label')}}</p>
                        <v-spacer></v-spacer>
                      </v-toolbar>
                      <v-flex>
                        <v-flex xs12 sm12 md12 lg12 xl12 class="pa-4">
                          <vue-form-generator
                            :schema="schemas"
                            custom-attribute="Language Codes"
                            :model="model"
                          ></vue-form-generator>
                          <v-card-actions>
                            <v-spacer></v-spacer>
                          </v-card-actions>
                        </v-flex>
                      </v-flex>
                    </v-card>
                  </v-flex>
                </v-layout>
              </v-tab-item>
            </v-tabs>
          </v-flex>
        </v-layout>
      </v-flex>
    </v-content>
  </v-app>
</template>
<script type="text/javascript" src="./js/schemaFormParser.js">
</script>
<style>
@import "./css/schemaFormParser.css";
</style>
