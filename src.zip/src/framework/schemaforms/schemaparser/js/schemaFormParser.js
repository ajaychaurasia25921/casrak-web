import {
  error,
  info,
  primaryColor,
  secondaryColor,
  success,
  warning
} from "@/themes/themeUtil.js";
import Vue from "vue";
import VueFormGenerator from "vue-form-generator";
import {
  getData
} from "@/framework/schemaforms/schemaparser/js/schemaGeneraterUtil.js";
import languageFormSchema from "@/store/formschemas/language/languageFormSchema.json";
import mapper from "@/store/formschemas/mapper.json";
import sortable from "sortablejs";
Vue.use(VueFormGenerator);
let currentItem = "",
  fieldsData = [],
  schemaStore = "",
  updateJSON = "";
export default {
  "components": {
    "vue-form-generator": VueFormGenerator.component
  },
  created() {
    for (const sc in mapper) this.allschema.push(sc);
    this.generateFile(languageFormSchema);
  },
  "data": () => {
    return {
      "AutoValid": true,
      "ChecklistValid": true,
      "RadioValid": false,
      "SelectValid": false,
      "active": " ",
      "addFieldValid": false,
      "addNewField": false,
      "alert": false,
      "allschema": [],
      "autoCompleteArray": [],
      "autoCompleteTableArray": [],
      "checkEdit": "",
      "checkListDialog": false,
      "checkboxArray": [],
      "checkboxValues": "",
      "checklistArray": [],
      "checklistTableArray": [],
      "checklistValues": "",
      "current": "",
      "dataExistsAlert": false,
      "defaultText": "",
      "deleteConfirmEditAuto": false,
      "deleteConfirmEditChecklist": false,
      "deleteConfirmEditRadio": false,
      "deleteConfirmEditSelect": false,
      "deleteConfirmRadio": false,
      "deleteMainTable": false,
      "dialog": false,
      "dialog1": false,
      "disable": true,
      "display": false,
      "displayTable": false,
      "edcurrentItemaxLength": "",
      "edcurrentIteminLength": "",
      "editAutoDialog": false,
      "editAutoID": "",
      "editAutoValue": "",
      "editCheckList": "",
      "editChecklistDialog": false,
      "editDefaultText": "",
      "editField": false,
      "editFieldName": "",
      "editHint": "",
      "editPlaceHolder": "",
      "editRadioDialog": false,
      "editRadioItem": "",
      "editRequired": true,
      "editSelectItem": "",
      "editTitle": "",
      "editType": "",
      error,
      "featured": true,
      "fieldName": "",
      "hint": "",
      info,
      "key": "",
      "languageSchemaContent": [],
      "languageSchemas": [],
      "maxLength": "",
      "minLength": "",
      "model": {
      },
      "optionsAutoComplete": false,
      "optionsChecklist": false,
      "optionsEditAutoComplete": false,
      "optionsEditChecklist": false,
      "optionsEditRadio": false,
      "optionsEditSelect": false,
      "optionsRadio": false,
      "optionsSelect": false,
      "placeholder": "",
      primaryColor,
      "radioTableArray": [],
      "radioboxArray": [],
      "radiosArray": [],
      "radiosValues": "",
      "readonly": true,
      "required": true,
      "rule": [v => {
        return Boolean(v) || "Value Required";
      },
      v => {
        return v && v.length !== 0 || "Enter Value";
      }],
      "ruleAdd": [v => {
        return Boolean(v) || "Value Required";
      },
      v => {
        return v && v.length !== 0 || "Enter Value";
      },
      v => {
        return (/^[a-zA-Z_-]+$/).test(v) || "Enter valid name";
      }],
      "schema": "",
      "schemaTitles": [],
      "schemaTypes": [],
      "schemas": {
        "groups": [{
          "fields": [{
          }]
        }]
      },
      secondaryColor,
      "section": [],
      "selectDialog": false,
      "selectSection": "",
      "selectTableValues": [],
      "selectValue": "",
      "selectValuesArray": [],
      "selectschema": "",
      success,
      "tableContent": [],
      "title": "",
      "type": "",
      "types": ["AutocompleteField",
        "CheckboxField",
        "RadioField",
        "TextField",
        "InputField",
        "SelectField",
        "TextAreaField",
        "Checklist",
        "Label",
        "Calendar"],
      "val": "",
      "value": "",
      "values": "",
      warning
    };
  },
  "methods": {
    addNewFiel() {
      this.addNewField = true;
      this.editField = false;
    },
    addOptions() {
      switch (this.type) {
      case "AutocompleteField":
        this.optionsAutoComplete = true;
        break;
      case "Checklist":
        this.optionsChecklist = true;
        break;
      case "SelectField":
        this.optionsSelect = true;
        break;
      case "RadioField":
        this.optionsRadio = true;
        break;
      default:
        return null;
      }
      return null;
    },
    addSaveSchema() {
      let n = 0;
      if (this.$refs.addForm.validate()) {
        this.snackbar = true;
        this.addNewField = false;
        const properties = [],
          newRecord =
            `"${this.fieldName}"` +
            ":{" +
            `"type":"${this.type}","required":${this.required},"disabled":${this.disable},"hint":"${this.hint}","placeholder":"${this.placeholder}","default":"${this.defaultText}","featured":${this.featured},"readonly":${this.readonly},"minLength":"${this.minLength}","model":"${this.title}","maxLength":"${this.maxLength}","attrs": {"titles":"${this.title}"}},`;
        updateJSON = JSON.stringify(languageFormSchema.properties);
        updateJSON =
          updateJSON.substring(0, 1) + newRecord + updateJSON.substring(1);
        switch (this.type) {
        case "AutocompleteField":
          n = updateJSON.search("\"default\"");
          updateJSON = `${updateJSON.substring(0, n)}"values":[${
            this.autoCompleteArray
          }],${updateJSON.substring(n)}`;
          break;
        case "RadioField":
          n = updateJSON.search("\"default\"");
          updateJSON = `${updateJSON.substring(0, n)}"values":[${
            this.radioboxArray
          }],${updateJSON.substring(n)}`;
          break;
        case "SelectField":
          n = updateJSON.search("\"default\"");
          updateJSON = `${updateJSON.substring(0, n)}"values":[${
            this.selectValuesArray
          }],${updateJSON.substring(n)}`;

          break;
        case "checklist":
          n = updateJSON.search("\"default\"");
          updateJSON = `${updateJSON.substring(0, n)}"values":[${
            this.checklistArray
          }],${updateJSON.substring(n)}`;
          break;
        }
        for (const r in languageFormSchema.sections) if (this.val.localeCompare(r) === 0) languageFormSchema.sections[r].push(this.fieldName);
        updateJSON = JSON.parse(updateJSON);
        const res = this.fieldName.toLocaleLowerCase();
        for (const i in languageFormSchema.properties) properties.push(i);

        for (let i = 0; i < properties.length; i++) {
          properties[i] = properties[i].toLocaleLowerCase();
          if (res.localeCompare(properties[i]) === 0) {
            this.dataExistsAlert = true;
            break;
          }
        }
        languageFormSchema.properties = updateJSON;
        this.generateFile(languageFormSchema);
        this.tableContent = [];
        this.selectSections(this.val);
        this.verify();
        this.$refs.addForm.resetValidation();
        this.autoCompleteArray = [];
        this.autoCompleteTableArray = [];
        this.radioboxArray = [];
        this.radioTableArray = [];
        this.selectValuesArray = [];
        this.selectTableValues = [];
        this.checklistArray = [];
        this.checklistTableArray = [];
      }
    },
    autoCompleteAdd(id, key) {
      let counter = 0,
        i = 0;
      if (this.$refs.form.validate()) {
        this.snackbar = true;
        if (this.autoCompleteArray.length === 0) {
          this.autoCompleteArray.push(`${"{\"text\":" + "\""}${key}"` + "," + "\"value\":" + `"${id}"}`);
          this.autoCompleteTableArray.push({
            "text": id,
            "value": key
          });
        } else {
          for (i = 0; i < this.autoCompleteTableArray.length; i++) if (id.localeCompare(this.autoCompleteTableArray[i].text) === 0) {
            counter++;
            break;
          }

          for (let j = 0; j < this.autoCompleteTableArray.length; j++) if (key.localeCompare(this.autoCompleteTableArray[j].value) === 0) {
            counter++;
            break;
          }

          if (counter === 0) {
            this.autoCompleteArray.push(`${"{\"text\":" + "\""}${key}"` + "," + "\"value\":" + `"${id}"}`);
            this.autoCompleteTableArray.push({
              "text": id,
              "value": key
            });
          } else this.dataExistsAlert = true;
        }
        this.$refs.form.resetValidation();
      }
      this.key = "";
      this.value = "";
      counter = 0;
    },
    checklistAdd(checklistValues) {
      let counter = 0;
      if (this.$refs.checkListform.validate()) {
        this.snackbar = true;
        const str = `"${checklistValues}"`;
        if (this.checklistArray.length === 0) {
          this.checklistTableArray.push(checklistValues);
          this.checklistArray.push(str);
        } else {
          for (let i = 0; i < this.checklistArray.length; i++) if (this.checklistArray[i].localeCompare(str) === 0) {
            counter++;
            break;
          }

          if (counter === 0) {
            this.checklistTableArray.push(checklistValues);
            this.checklistArray.push(`"${checklistValues}"`);
          } else this.dataExistsAlert = true;
        }
        this.$refs.checkListform.resetValidation();
      }
      counter = 0;
      this.checklistValues = "";
    },
    deleteAuto(item) {
      currentItem = item;
      if (this.deleteConfirmEditAuto) this.deleteConfirmEditAuto = true;
      else this.deleteConfirmEditAuto = true;
    },
    deleteChecklistItem(item) {
      currentItem = item;
      this.deleteConfirmEditChecklist = true;
    },
    deleteConfirmEditAutos() {
      this.deleteConfirmEditAuto = false;
      const str = `{"text":"${currentItem.value}","value":"${currentItem.text}"}`,
        tableIndex = this.autoCompleteTableArray.indexOf(currentItem),
        index = this.autoCompleteArray.indexOf(str);
      this.autoCompleteTableArray.splice(tableIndex, 1);
      this.autoCompleteArray.splice(index, 1);
    },
    deleteConfirmEditChecklists() {
      this.deleteConfirmEditChecklist = false;
      const indexValue = this.checklistArray.indexOf(`"${currentItem}"`),
        index = this.checklistTableArray.indexOf(currentItem);
      this.checklistTableArray.splice(index, 1);
      this.checklistArray.splice(indexValue, 1);
    },
    deleteConfirmEditRadios() {
      this.deleteConfirmEditRadio = false;
      const index = this.radioTableArray.indexOf(currentItem),
        indexValue = this.radioboxArray.indexOf(`"${currentItem}"`);
      this.radioTableArray.splice(index, 1);
      this.radioboxArray.splice(indexValue, 1);
    },
    deleteConfirmEditSelects() {
      this.deleteConfirmEditSelect = false;
      const index = this.selectTableValues.indexOf(currentItem),
        indexValue = this.selectValuesArray.indexOf(`"${currentItem}"`);
      this.selectTableValues.splice(index, 1);
      this.selectValuesArray.splice(indexValue, 1);
    },
    deleteItem(item) {
      currentItem = item;
      this.deleteMainTable = true;
    },
    deleteMainTables() {
      this.deleteMainTable = false;
      const properties = [],
        index = this.tableContent.indexOf(currentItem);
      this.tableContent.splice(index, 1);
      for (const i in languageFormSchema.properties) properties.push(i);

      for (let i = 0; i < properties.length; i++) if (currentItem.key === properties[i]) delete languageFormSchema.properties[currentItem.key];
      const valIndex = languageFormSchema.required.indexOf(currentItem.key),
        valSecIndex = languageFormSchema.sections[this.selectSection].indexOf(currentItem.key);
      languageFormSchema.required.splice(valIndex, 1);
      languageFormSchema.sections[this.selectSection].splice(valSecIndex, 1);
      this.generateFile(languageFormSchema);
      this.selectSections(this.val);
      currentItem = "";
    },
    deleteRadioItem(item) {
      currentItem = item;
      this.deleteConfirmEditRadio = true;
    },
    deleteSelectItem(item) {
      currentItem = item;
      this.deleteConfirmEditSelect = true;
    },
    editAutoItem(item) {
      currentItem = item;
      this.editAutoID = item.text;
      this.editAutoValue = item.value;
      this.editAutoDialog = true;
    },
    editAutoItemSave(id, key) {
      this.editAutoDialog = false;
      const str = `{"text":"${currentItem.value}","value":"${currentItem.text}"}`,
        strResult = `{"text":"${id}","value":"${key}"}`,
        index = this.autoCompleteArray.indexOf(str),
        objIndex = this.autoCompleteTableArray.indexOf(currentItem);
      this.autoCompleteTableArray[objIndex].value = key;
      this.autoCompleteTableArray[objIndex].text = id;
      this.autoCompleteArray[index] = strResult;
    },
    editChecklistItem(item) {
      currentItem = item;
      this.editChecklistDialog = true;
      this.editCheckList = item;
    },
    editChecklistSave(val) {
      this.editChecklistDialog = false;
      const index = this.checklistArray.indexOf(`"${currentItem}"`),
        objIndex = this.checklistTableArray.indexOf(currentItem);
      this.checklistTableArray[objIndex] = val;
      this.checklistArray[index] = `"${val}"`;
    },
    editFiel(item) {
      this.editField = true;
      this.addNewField = false;
      this.editFieldName = item.key;
      this.editTitle = item.labels;
      this.editType = item.type;
      this.edcurrentIteminLength = item.min;
      this.edcurrentItemaxLength = item.max;
      this.featured = item.featured;
      this.readonly = item.readonly;
      this.editPlaceHolder = item.placeholder;
      switch (this.editType) {
      case "AutocompleteField":
        this.autoCompleteTableArray = item.values;
        break;
      case "RadioField":
        this.radioTableArray = item.values;
        break;
      case "SelectField":
        this.selectTableValues = item.values;
        break;
      case "checklist":
        this.checklistTableArray = item.values;
        break;
      }
    },
    editOptions() {
      switch (this.editType) {
      case "AutocompleteField":
        this.optionsEditAutoComplete = true;
        break;
      case "Checklist":
        this.optionsEditChecklist = true;
        break;
      case "SelectField":
        this.optionsEditSelect = true;
        break;
      case "RadioField":
        this.optionsEditRadio = true;
        break;
      default:
        return null;
      }
      return null;
    },
    editRadioItems(item) {
      currentItem = item;
      this.editRadioDialog = true;
      this.editRadioItem = item;
    },
    editRadioSave(val) {
      this.editRadioDialog = false;
      const str = `"${val}"`,
        objIndex = this.radioTableArray.indexOf(currentItem),
        index = this.radioboxArray.indexOf(`"${currentItem}"`);
      this.radioTableArray[objIndex] = val;
      this.radioboxArray[index] = str;
    },
    editSelectItems(item) {
      currentItem = item;
      this.selectDialog = true;
      this.editSelectItem = item;
    },
    editSelectSave(val) {
      this.selectDialog = false;
      const index = this.selectValuesArray.indexOf(`"${currentItem}"`),
        objIndex = this.selectTableValues.indexOf(currentItem),
        str = `"${val}"`;
      this.selectTableValues[objIndex] = val;
      this.selectValuesArray[index] = str;
    },
    editaddSaveSchema() {
      let n = 0,
        sel = [];
      const rad = [],
        chk = [],
        aut = [];
      this.editField = false;
      const properties = [],
        newRecord =
          `"${this.editFieldName}"` +
          ":{" +
          `"type":"${this.editType}","required":${this.editRequired},"disabled":${this.disable},"hint":"${this.editHint}","placeholder":"${this.editPlaceHolder}","default":"${this.editDefaultText}","featured":${this.featured},"readonly":${this.readonly},"minLength":"${this.edcurrentIteminLength}","maxLength":"${this.edcurrentItemaxLength}","model":"${this.editTitle}","attrs": {"titles":"${this.editTitle}"}},`;
      updateJSON = JSON.stringify(languageFormSchema.properties);
      updateJSON =
        updateJSON.substring(0, 1) + newRecord + updateJSON.substring(1);
      switch (this.editType) {
      case "AutocompleteField":
        this.autoCompleteArray = [];
        for (let i = 0; i < this.autoCompleteTableArray.length; i++) {
          this.autoCompleteArray.push(`${"{\"value\":" + "\""}${this.autoCompleteTableArray[i].value}"` +
                "," +
                "\"text\":" +
                `"${this.autoCompleteTableArray[i].text}"}`);
          aut.push({
            "value": this.autoCompleteTableArray[i].value,
            "text": this.autoCompleteTableArray[i].text
          });
        }
        n = updateJSON.search("\"default\"");
        updateJSON = `${updateJSON.substring(0, n)}"values":[${
          this.autoCompleteArray
        }],${updateJSON.substring(n)}`;

        break;
      case "RadioField":
        this.radioboxArray = [];
        for (let i = 0; i < this.radioTableArray.length; i++) {
          this.radioboxArray.push(`"${this.radioTableArray[i]}"`);
          rad.push(this.radioTableArray[i]);
        }
        n = updateJSON.search("\"default\"");
        updateJSON = `${updateJSON.substring(0, n)}"values":[${
          this.radioboxArray
        }],${updateJSON.substring(n)}`;
        break;

      case "SelectField":
        this.selectValuesArray = [];
        for (let i = 0; i < this.selectTableValues.length; i++) {
          this.selectValuesArray.push(`"${this.selectTableValues[i]}"`);
          sel.push(this.selectTableValues[i]);
        }
        n = updateJSON.search("\"default\"");
        updateJSON = `${updateJSON.substring(0, n)}"values":[${
          this.selectValuesArray
        }],${updateJSON.substring(n)}`;
        break;

      case "checklist":
        this.checklistArray = [];
        for (let i = 0; i < this.checklistTableArray.length; i++) {
          this.checklistArray.push(`"${this.checklistTableArray[i]}"`);
          chk.push(this.checklistTableArray[i]);
        }
        n = updateJSON.search("\"default\"");
        updateJSON = `${updateJSON.substring(0, n)}"values":[${
          this.checklistArray
        }],${updateJSON.substring(n)}`;
        break;
      }
      updateJSON = JSON.parse(updateJSON);
      const res = this.editFieldName.toLocaleLowerCase();
      for (const i in languageFormSchema.properties) properties.push(i);
      for (let i = 0; i < properties.length; i++) if (res.localeCompare(properties[i].toLowerCase()) === 0) {
        updateJSON[properties[i]].maxLength = this.edcurrentItemaxLength;
        updateJSON[properties[i]].minLength = this.edcurrentIteminLength;
        updateJSON[properties[i]].type = this.editType;
        switch (this.editType) {
        case "AutocompleteField":
          updateJSON[properties[i]].values = aut;
          break;
        case "RadioField":
          updateJSON[properties[i]].values = rad;
          break;
        case "SelectField":
          updateJSON[properties[i]].values = sel;
          break;
        case "checklist":
          updateJSON[properties[i]].values = chk;
          break;
        }
        updateJSON[properties[i]].attrs.titles = this.editTitle;
      }
      sel = [];
      languageFormSchema.properties = updateJSON;
      this.generateFile(languageFormSchema);
      this.selectSections(this.val);
      this.autoCompleteArray = [];
      this.autoCompleteTableArray = [];
      this.radioboxArray = [];
      this.radioTableArray = [];
      this.selectValuesArray = [];
      this.selectTableValues = [];
      this.checklistArray = [];
      this.checklistTableArray = [];
    },
    generateFile(json) {
      this.schemas.groups[0].fields = getData(json);
      localStorage.setItem("rednderDataLocalStorage",
        JSON.stringify(fieldsData));
    },
    onLoad() {
      // LanguageFormSchema = this.schema;
    },
    radiosAdd(radiosValues) {
      let counter = 0;
      if (this.$refs.radioForm.validate()) {
        this.snackbar = true;
        const str = `"${radiosValues}"`;
        if (this.radioboxArray.length === 0) {
          this.radioboxArray.push(str);
          this.radioTableArray.push(radiosValues);
        } else {
          for (let i = 0; i < this.radioboxArray.length; i++) if (str.localeCompare(this.radioboxArray[i]) === 0) {
            counter++;
            break;
          }

          if (counter === 0) {
            this.radioboxArray.push(str);
            this.radioTableArray.push(radiosValues);
          } else this.dataExistsAlert = true;
        }
        this.$refs.radioForm.resetValidation();
      }
      counter = 0;
      this.radiosValues = "";
    },
    selectSec() {
      for (const sections in languageFormSchema.sections) this.languageSchemaContent.push(sections);
    },
    selectSections(value) {
      this.displayTable = true;
      this.val = value;
      const {
        required
      } = languageFormSchema;
      this.section = [];
      let json = "",
        tableData = {
        };
      const content = [];
      for (const i in languageFormSchema.sections) if (value.localeCompare(i) === 0) for (let k = 0; k < languageFormSchema.sections[i].length; k++) this.section.push(languageFormSchema.sections[i][k]);
      fieldsData = [];
      for (let a = 0; a < this.section.length; a++) {
        for (const j in languageFormSchema.properties) if (this.section[a].localeCompare(j) === 0) {
          json = JSON.stringify(languageFormSchema.properties[j]);
          for (let m = 0; m < required.length; m++) if (required[m].localeCompare(j) === 0) {
            json = JSON.stringify(languageFormSchema.properties[j]);
            json = json.replace(/^{/, "{\"required\":true,");
          }
          if ((/"[a-z|A-Z|0-9]*":{/g).test(json)) json = json.replace(/,"[a-z|A-Z|0-9]*":{/g, ",");
          if ((/}}/).test(json)) json = json.replace(/}}/g, "}");
          if ((/],"^[a-z|A-Z|0-9]*":{/).test(json)) json = json.replace(/"],"[a-z|A-Z|0-9]*":{/g, "],");
          json = json.
            replace(/"type":"email"/gi, "\"inputType\":\"email\"").
            replace(/minlength/gi, "minlength").
            replace(/minimum/gi, "minlength").
            replace(/maxlength/gi, "maxlength").
            replace(/titles/gi, "labels").
            replace(/"type":"textarea"/gi, "\"type\":\"TextAreaField\"").
            replace(/"type":"boolean"/gi,
              "\"type\":\"RadioField\",\"styleClasses\":\"width-50 col-xs-1 text-left\"").
            replace(/[0-9#$%^&*()_+,!@]}/gi, "}");
          if ((/enum/gi).test(json)) json = json.replace(/enum/gi, "values");
          if ((/"type":"input"/gi).test(json)) json = json.replace(/"type":"input"/gi,
            "\"type\":\"InputField\",\"styleClasses\":\"width-50 col-xs-1 text-left\"");
          if ((/"type":"checklist"/gi).test(json)) json = json.replace(/"type":"checklist"/gi,
            `"type":"checklist","listBox": true,"values":[${this.checklistArray}]`);
          if ((/"type":"autocomplete"/gi).test(json)) json = json.replace(/"type":"autocomplete"/gi,
            `"type":"AutocompleteField","values":[${this.autoCompleteArray}]`);
          if ((/"type":"string"/gi).test(json)) json = json.replace(/"type":"string"/gi,
            "\"type\":\"InputField\",\"inputType\":\"text\", \"styleClasses\":\"width-50 text-left\"");
          updateJSON = `{"${this.section[a]}":${json}}`;
          content.push(updateJSON);
        }
        this.tableContent = [];
        for (let t = 0; t < content.length; t++) {
          tableData = JSON.parse(content[t]);
          for (const prop in tableData) this.tableContent.push({
            "key": prop,
            "label": tableData[prop].labels,
            "type": (function () {
              switch (tableData[prop].type) {
              case "AutocompleteField":
                return "Input";
              case "CheckboxField":
                return "Checkbox";
              case "RadioField":
                return "Radio";
              case "TextField":
                return "Text";
              case "SelectField":
                return "Select";
              case "TextAreaField":
                return "Text Area";
              case "InputField":
                return "Input";
              case "switch":
                return "Switch";
              }
              return null;
            }()),
            // Type: tableData[prop].type,
            "inputType": tableData[prop].inputType,
            "required": tableData[prop].required ? "Yes" : "No",
            "placeholder": tableData[prop].placeholder,
            "values": tableData[prop].values,
            "max": tableData[prop].max,
            "min": tableData[prop].min
          });
        }
      }
    },
    selectValueAdd(selectValue) {
      let counter = 0;
      if (this.$refs.SelectValids.validate()) {
        this.snackbar = true;
        const str = `"${selectValue}"`;
        if (this.selectValuesArray.length === 0) {
          this.selectTableValues.push(selectValue);
          this.selectValuesArray.push(str);
        } else {
          for (let i = 0; i < this.selectValuesArray.length; i++) if (str.localeCompare(this.selectValuesArray[i]) === 0) {
            counter++;
            break;
          }

          if (counter === 0) {
            this.selectTableValues.push(selectValue);
            this.selectValuesArray.push(str);
          } else this.dataExistsAlert = true;
        }
        this.$refs.SelectValids.resetValidation();
      }
      counter = 0;
      this.selectValue = "";
    }
  },
  mounted() {
    const table = document.querySelector(".v-datatable tbody"),
      _self = this;
    sortable.create(table, {
      "handle": ".handle",
      onEnd({
        newIndex, oldIndex
      }) {
        const rowSelected = _self.tableContent.splice(oldIndex, 1)[0];
        _self.tableContent.splice(newIndex, 0, rowSelected);
      }
    });
    if (localStorage.getItem("schemaStore")) schemaStore = JSON.parse(localStorage.getItem("schemaStore"));
  },
  "watch": {
    "deep": true,
    "schemaStore": {
      handler() {
        localStorage.setItem("schemaStore", JSON.stringify(schemaStore));
      }
    }
  }
};
