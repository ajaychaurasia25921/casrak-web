let fieldsData = [],
  models = [],
  fieldsDatas = [],
  sections = [],
  result = [],
  removeDuplicate = [],
  getData = function (jsons) {
    let json = "",
      {
        required
      } = jsons;
    result = [];
    models = [];
    fieldsDatas = [];
    fieldsData = [];
    sections = [];
    required = [];
    removeDuplicate = [];
    for (const model in jsons.properties) models.push(model);
    for (const property in jsons.properties) {
      json = JSON.stringify(jsons.properties[property]);
      fieldsDatas.push(json);
      sections = fieldsDatas;
    }
    if (jsons) {
      for (let k = 0; k < required.length; k++) for (const prop in jsons.properties) if (prop == required[k]) {
        json = JSON.stringify(jsons.properties[prop]);
        json = json.replace(/^{/, "{\"required\":true,");
        result.push(json);
      } else {
        json = JSON.stringify(jsons.properties[prop]);
        removeDuplicate.push(json);
      }
      removeDuplicate = removeDuplicates(removeDuplicate);
      result = sections;
      for (let i = 0; i < result.length; i++) {
        json = result[i];
        if ((/"[a-z|A-Z|0-9]*":{/g).test(json)) json = json.replace(/,"[a-z|A-Z|0-9]*":{/g, ",");

        if ((/}}/).test(json)) json = json.replace(/}}/g, "}");

        if ((/],"^[a-z|A-Z|0-9]*":{/).test(json)) json = json.replace(/"],"[a-z|A-Z|0-9]*":{/g, "],");

        json = json.
          replace(/"type":"email"/gi, "\"inputType\":\"email\"").
          replace(/minlength/gi, "minlength").
          replace(/minimum/gi, "minlength").
          replace(/maxlength/gi, "maxlength").
          replace(/titles/gi, "labels").
          replace(/"type":"textarea"/gi, "\"type\":\"TextAreaField\"").
          replace(/"type":"boolean"/gi,
            "\"type\":\"RadioField\",\"styleClasses\":\"width-50 col-xs-1 text-left\"").
          replace(/[0-9#$%^&*()_+,!@]}/gi, "}");
        if ((/enum/gi).test(json)) json = json.replace(/enum/gi, "values");

        if ((/"type":"input"/gi).test(json)) json = json.replace(/"type":"input"/gi,
          "\"type\":\"InputField\",\"styleClasses\":\"width-50 col-xs-1 text-left\"");

        if ((/"type":"checklist"/gi).test(json)) json = json.replace(/"type":"checklist"/gi,
          `"type":"checklist","listBox": true,"values":[${
            this.checklistArray
          }]`);

        if ((/"type":"autocomplete"/gi).test(json)) json = json.replace(/"type":"autocomplete"/gi,
          `"type":"AutocompleteField","values":[${this.autoCompleteArray}]`);

        if ((/"type":"string"/gi).test(json)) json = json.replace(/"type":"string"/gi,
          "\"type\":\"InputField\",\"inputType\":\"text\", \"styleClasses\":\"width-50 text-left\"");

        if ((/"type":"number"/gi).test(json)) json = json.replace(/"type":"number"/gi,
          "\"type\":\"InputField\",\"inputType\":\"number\", \"styleClasses\":\"width-50 text-left\"");

        if ((/"type":"select"/gi).test(json)) json = json.replace(/"type":"select"/gi,
          "\"type\":\"select\",\"styleClasses\":\"width-50 text-left\"");

        if ((/"type":"switch"/gi).test(json)) json = json.replace(/"type":"switch"/gi,
          "\"type\":\"SwitchField\",\"styleClasses\":\"width-50 text-left\"");

        json = JSON.parse(json);
        fieldsData.push(json);
      }
    }
    return fieldsData;
  };

function removeDuplicates(res) {
  const unique = {

  };
  res.forEach(i => {
    if (!unique[i]) unique[i] = true;
  });
  return Object.keys(unique);
}

export {
  getData
};
