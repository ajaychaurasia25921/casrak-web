import axios from "axios";
import authentication from "@/framework/authentication/tokenmanagement/modules/modules_authentication";
// eslint-disable-next-line no-undef 
let url = require("@/service_properties.json");
import { getJSONFromFile } from "@/utils/fileUtilities.js";
url = getJSONFromFile(url);
import errorResponseHandler from "@/framework/errorhandler.js";
// eslint-disable-next-line no-undef
let keyCloack = require("@/configuration_properties.json");
// eslint-disable-next-line no-undef
keyCloack = getJSONFromFile(keyCloack);
import NProgress from "nprogress";
import "nprogress/nprogress.css";

export default function setup() {
  axios.interceptors.request.use(
    function(config) {
      const token = authentication.state.token;
      if (token) {
         if (
        url.authentication.use_bearer_token &&
          !keyCloack.serverSettings.keyCloackEnabled
      ) config.headers.Authorization = `Bearer ${token}`;
      else config.headers.Authorization = `${token}`;
        NProgress.start();
        NProgress.set(0.5);
      }
      return config;
    },
    function(err) {
      return Promise.reject(err);
    }
  );
  axios.interceptors.response.use(
    function(response) {
      NProgress.done();
      return response;
    },
    function(error) {
      NProgress.done();
      return errorResponseHandler(error);
    }
  );
}
