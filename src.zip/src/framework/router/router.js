import Vue from "vue";
import Router from "vue-router";
import store from "@/store";
import NProgress from "nprogress";
import {
  getJSONFromFile
} from "@/utils/fileUtilities.js";
// eslint-disable-next-line no-undef
let config = require("@/configuration_properties.json");
config = getJSONFromFile(config);
let roles = [];

const LoginScreen = () => {
    return import(
      /* WebpackChunkName:"common" */ "@/components/common/Login.vue");
  },
  PageNotFound = () => {
    return import(
      /* WebpackChunkName:"common" */ "@/components/common/PageNotFound.vue");
  },
  NotPermitted = () => {
    return import(
      /* WebpackChunkName:"common" */ "@/components/common/NotPermitted.vue");
  },
  Help = () => {
    return import(
      /* WebpackChunkName:"common" */ "@/components/common/Help.vue");
  },
  ConfigurationProperties = () => {
    return import(
      /* WebpackChunkName:"common" */ "@/components/common/Configuration.vue");
  },
  Home = () => {
    return import(
      /* WebpackChunkName:"common" */ "@/components/common/Home.vue");
  },
  // Functional Components
  ResourceAnalysis = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/ResourceAnalysis.vue");
  },
  DemandAndSupplyAnalysis = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/DemandAndSupplyAnalysis.vue");
  },
  ManageProfile = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/ManageProfile.vue");
  },
  Organization = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/Organization.vue");
  },
  OrganizationJiraProject = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/OrganizationJiraProject.vue");
  },
  ProjectTask = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/ProjectTask.vue");
  },
  LocationCapacity = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/LocationCapacity.vue");
  },
  RoleManagement = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/RoleManagement.vue");
  },
  UserCapacity = () => {
    return import(
      /* WebpackChunkName:"functional" */ "@/components/functional/UserCapacity.vue");
  };

Vue.use(Router);

const ifNotAuthenticated = (to, from, next) => {
    if (!store.getters.isAuthenticated) {
      next();
      return;
    }
    next("/");
  },
  ifAuthenticated = (to, from, next) => {
    if (store.getters.isAuthenticated) {
      next();
      return;
    }
    next("/");
  },
  router = new Router({
    "routes": [{
      "path": "/",
      "name": "LoginScreen",
      "component": LoginScreen,
      "beforeEnter": ifNotAuthenticated
    },
    {
      "path": "/common/home",
      "name": "Home",
      "component": Home,
      "beforeEnter": ifAuthenticated
    },
    {
      "path": "/common/configurationProperties",
      "name": "ConfigurationProperties",
      "component": ConfigurationProperties,
      "beforeEnter": ifAuthenticated,
      "meta": {
        "conditionalManager": true,
        "conditionalAppUser": true,
        "conditionalAdministrator": false
      }
    },
    {
      "path": "/functional/projectTask",
      "name": "ProjectTask",
      "component": ProjectTask,
      "beforeEnter": ifAuthenticated
    },
    {
      "path": "/functional/demandAndSupplyAnalysis",
      "name": "DemandAndSupplyAnalysis",
      "component": DemandAndSupplyAnalysis,
      "beforeEnter": ifAuthenticated
    },
    {
      "path": "/functional/resourceAnalysis",
      "name": "ResourceAnalysis",
      "component": ResourceAnalysis,
      "beforeEnter": ifAuthenticated,
      "meta": {
        "conditionalAppUser": true
      }
    },
    {
      "path": "/functional/userCapacity",
      "name": "UserCapacity",
      "component": UserCapacity,
      "beforeEnter": ifAuthenticated
    },
    {
      "path": "/functional/roleManagement",
      "name": "RoleManagement",
      "component": RoleManagement,
      "beforeEnter": ifAuthenticated,
      "meta": {
        "conditionalManager": true,
        "conditionalAppUser": true,
        "conditionalAdministrator": false
      }
    },
    {
      "path": "/functional/manageProfile",
      "name": "ManageProfile",
      "component": ManageProfile,
      "beforeEnter": ifAuthenticated
    },
    {
      "path": "/functional/organization",
      "name": "Organization",
      "component": Organization,
      "beforeEnter": ifAuthenticated,
      "meta": {
        "conditionalAppUser": true
      }
    },
    {
      "path": "/functional/locationCapacity",
      "name": "LocationCapacity",
      "component": LocationCapacity,
      "beforeEnter": ifAuthenticated,
      "meta": {
        "conditionalAppUser": true
      }
    },
    {
      "path": "/functional/organizationJiraProject",
      "name": "OrganizationJiraProject",
      "component": OrganizationJiraProject,
      "beforeEnter": ifAuthenticated,
      "meta": {
        "conditionalAppUser": true
      }
    },
    {
      "path": "/common/notPermitted",
      "name": "NotPermitted",
      "component": NotPermitted,
      "beforeEnter": ifAuthenticated
    },
    {
      "path": "*",
      "redirect": "/404"
    },
    {
      "path": "/404",
      "name": "PageNotFound",
      "component": PageNotFound
    },
    {
      "path": "/common/help",
      "name": "Help",
      "component": Help,
      "beforeEnter": ifAuthenticated
    }]
  });
router.beforeEach((to, from, next) => {
  if (
    to.matched.some(record => {
      if (
        config.serverSettings.keyCloackEnabled &&
        localStorage.keycloakDetails &&
        roles.length == 0
      ) {
        const checkCondition = JSON.parse(localStorage.getItem("keycloakDetails"));
        roles = checkCondition.rolesDetails.roles;
      }
      if (roles.includes("MANAGER")) return record.meta.conditionalManager;
      else if (roles.includes("APPUSER")) return record.meta.conditionalAppUser;
      else if (roles.includes("AMINISTRATOR")) return record.meta.conditionalAdministrator;
      return record.meta.conditionalAdministrator;
    })
  )
    // Check codition is false
    next({
      "path": "/common/notPermitted"
    });
  // Check codition is true
  else next();
  // Make sure to always call next()!
});
router.afterEach((to, from) => {
  NProgress.done();
  to;
  from;
});
export default router;
