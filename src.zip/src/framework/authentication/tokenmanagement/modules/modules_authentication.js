/* eslint-disable no-undef */
import {
  AUTHENTICATION_ERROR,
  AUTHENTICATION_LOGOUT,
  AUTHENTICATION_REQUEST,
  AUTHENTICATION_SUCCESS,
  GENERATE_TOKEN
} from "../actions/actions_authentication";

import axios from "axios";
import {
  getJSONFromFile
} from "@/utils/fileUtilities.js";
let url = require("@/service_properties.json");
url = getJSONFromFile(url);
// eslint-disable-next-line no-undef
let config = require("@/configuration_properties.json");
config = getJSONFromFile(config);

const state = {
    "token": localStorage.getItem("access-token") || "",
    "status": "",
    "hasLoadedOnce": false,
    "urlData": []
  },
  getters = {
    "isAuthenticated": state => {
      return Boolean(state.token);
    },
    "authStatus": state => {
      return state.status;
    }
  },
  actions = {
    [GENERATE_TOKEN]: () => {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0,
          v = c === "x" ? r : r & 0x3 | 0x8;
        return v.toString(16);
      });
    },
    [AUTHENTICATION_REQUEST]: ({
      commit, dispatch
    }, user) => {
      return new Promise((resolve, reject) => {
        commit(AUTHENTICATION_REQUEST);
        if (localStorage.keycloackAccessToken) commit(AUTHENTICATION_SUCCESS);
        else if (process.env.VUE_APP_API_CLIENT === "server") return axios({
          "url": url.authentication.authentication_url,
          "data": user,
          "method": "POST"
        }).
          then(resp => {
            if (process.env.VUE_APP_API_CLIENT === "server") if (!resp.error && resp.status === 200) {
              localStorage.setItem("access-token", resp.data.id_token);
              commit(AUTHENTICATION_SUCCESS, resp);
              resolve(resp);
            } else {
              resolve(resp);
            }
          }).
          catch(err => {
            commit(AUTHENTICATION_ERROR, err);
            localStorage.removeItem("access-token");
            reject(err);
          });
        dispatch(GENERATE_TOKEN).
          then(resp => {
            localStorage.setItem("access-token", resp);
            commit(AUTHENTICATION_SUCCESS, resp);
            resolve(resp);
          }).
          catch(err => {
            commit(AUTHENTICATION_ERROR, err);
            localStorage.removeItem("access-token");
            reject(err);
          });

        return undefined;
      });
    },
    [AUTHENTICATION_LOGOUT]: ({
      commit
    }) => {
      return new Promise(resolve => {
        commit(AUTHENTICATION_LOGOUT);
        localStorage.removeItem("access-token");
        localStorage.removeItem("username");
        localStorage.removeItem("keyCloakDetails");
        localStorage.removeItem("keycloackAccessToken");
        localStorage.removeItem("keycloacRefreshoken");
        resolve();
      });
    }
  },
  mutations = {
    [AUTHENTICATION_REQUEST]: state => {
      state.status = "loading";
    },
    [AUTHENTICATION_SUCCESS]: (state, resp) => {
      state.status = "success";

      if (localStorage.keycloackAccessToken) state.token = localStorage.getItem("keycloackAccessToken");

      if (
        config.serverSettings.keyCloackEnabled === false &&
        process.env.VUE_APP_API_CLIENT === "server"
      ) state.token = resp.data.id_token;

      if (process.env.VUE_APP_API_CLIENT === "mock") state.token = resp;

      state.hasLoadedOnce = true;
    },
    [AUTHENTICATION_ERROR]: state => {
      state.status = "error";
      state.hasLoadedOnce = true;
    },
    [AUTHENTICATION_LOGOUT]: state => {
      state.token = "";
    }
  };

export default {
  state,
  getters,
  actions,
  mutations
};
