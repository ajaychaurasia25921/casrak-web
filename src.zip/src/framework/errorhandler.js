let message = [],
  status = "";

function errorResponseHandler(error) {
  const statusCode =
    error.response && error.response.status ? error.response.status : "";
  message = [];
  status = "";
  if (!error.response.status) {
    if (error.response == "undefined") message[0] = error.message;
  } else switch (statusCode) {
  case 400:
    {
      if (!error.response.data.causes) {
        message[0] = error.response.data.detail;
        status = error.response.status;
      } else {
        for (let i = 0; i < error.response.data.causes.length; i++) message[i] = error.response.data.causes[i].message;

        status = error.response.status;
      }
    }
    break;
  case 401: {
    return error;
  }
  case 404:
    {
      message[0] = error.response.statusText;
      status = error.response.status;
    }
    break;
  case 500:
    {
      message[0] = error.response.statusText;
      status = error.response.status;
    }
    break;
  }

  return {
    "error": {
      message,
      status
    }
  };
}

export default errorResponseHandler;
